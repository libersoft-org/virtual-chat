const App = require('./libs/app.js');
const app = new App();
app.run();
